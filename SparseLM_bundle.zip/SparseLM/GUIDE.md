# SparseLM: guide to this bundle

A from-scratch PyTorch project with three parts. Use this file to find things quickly.

| Part | What | Main code |
|---|---|---|
| 1 | Decoder-only Transformer (~23M params, RMSNorm, RoPE, tied embeddings) with a swappable FFN: dense MLP or 4 Mixture-of-Experts layouts (top-1, top-2, 1 shared + 3 routed, wide top-2). vi/ja to en translation. | `src/part1/model.py` (MoE class, routing, load-balancing + z-loss), `src/part1/data.py`, `src/part1/train.py`, `src/part1/evaluate.py` |
| 2 | Five optimizers from scratch: AdamW, MARS, Lion, Muon (Newton-Schulz), Sophia-G (Gauss-Newton-Bartlett Hessian), plus an LR sweep. | `src/part2/optimizers/*.py`, `src/part2/train.py`, `src/part2/sweep.py` |
| 3 | Decoding from scratch on Pythia-160M with a KV cache: greedy, top-k, top-p, beam search. Metrics: perplexity, accuracy, unigram P/R/F1. | `src/part3/decoding.py`, `src/part3/metrics.py`, `src/part3/run.py` |

## Where the numbers are
- `report_data/tables.md`: every result table (Part 1 variants, routing statistics, optimizer curves over budget, LR sweep, decoding metrics, beam timing). Best source for charts.
- `report_data/metrics.json`: the same results as JSON.
- `report.tex`: the full written report (analysis and discussion).
- `problem-statement.pdf`: the original assignment.
- `configs/part{1,2,3}.yaml`: all hyperparameters.
- `tests/`: unit tests (parameter parity, AdamW matches torch, beam width 1 equals greedy, and more).

## Headline results
- Part 1: dense 31.04 BLEU (beam-4); MoE quality tracks active, not total, parameters; wide MoE (30M total, 22.9M active) ties dense.
- Part 2: final val loss MARS 4.073 < AdamW 4.093 < Muon 4.113 < Sophia 4.202 < Lion 4.209; ranking changes with training budget.
- Part 3: top-k (k=10) unigram F1 0.181 vs greedy 0.117 (+55% relative); greedy repeats 49% of 4-grams; beam search lowers perplexity but also F1.
